'use client'

import { createNamespacedLogger } from '@/lib/logger'

const logger = createNamespacedLogger('UseNotifications')
import { useState, useEffect, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Notification } from '@/types/notification'
import { useUser } from '@/lib/contexts/UserContext'

interface UseNotificationsReturn {
  notifications: Notification[]
  unreadCount: number
  isLoading: boolean
  error: Error | null
  markAsRead: (notificationId: string) => Promise<void>
  markAllAsRead: () => Promise<void>
  refetch: () => Promise<void>
}

export function useNotifications(): UseNotificationsReturn {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const { user } = useUser()

  const supabase = createClient()

  // 알림 조회
  const fetchNotifications = useCallback(async () => {
    try {
      setIsLoading(true)
      setError(null)

      if (!user) {
        setNotifications([])
        setUnreadCount(0)
        return
      }

      // 알림 기본 데이터 조회
      const { data, error: fetchError } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50)

      if (fetchError) throw fetchError

      // actor 정보를 배치 쿼리로 조회 (N+1 문제 해결)
      const actorIds = [...new Set(
        (data || [])
          .map(n => n.actor_id)
          .filter((id): id is string => !!id)
      )]

      let actorsMap = new Map<string, { id: string; full_name: string; avatar_url: string }>()

      if (actorIds.length > 0) {
        const { data: actorsData } = await supabase
          .from('profiles')
          .select('id, full_name, avatar_url')
          .in('id', actorIds)

        if (actorsData) {
          actorsMap = new Map(actorsData.map(a => [a.id, a]))
        }
      }

      const notificationsWithActor = (data || []).map(notification => {
        if (notification.actor_id && actorsMap.has(notification.actor_id)) {
          return { ...notification, actor: actorsMap.get(notification.actor_id) }
        }
        return notification
      })

      setNotifications(notificationsWithActor)
      setUnreadCount((data || []).filter(n => !n.is_read).length)
    } catch (err) {
      setError(err instanceof Error ? err : new Error('알림을 불러오는데 실패했습니다'))
      logger.error('Failed to fetch notifications:', err)
    } finally {
      setIsLoading(false)
    }
  }, [supabase, user])

  // 개별 알림 읽음 처리
  const markAsRead = useCallback(async (notificationId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId)

      if (updateError) throw updateError

      // 로컬 상태 업데이트
      setNotifications(prev =>
        prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
      )
      setUnreadCount(prev => Math.max(0, prev - 1))
    } catch (err) {
      logger.error('Failed to mark notification as read:', err)
    }
  }, [supabase])

  // 모든 알림 읽음 처리
  const markAllAsRead = useCallback(async () => {
    if (!user) return

    try {
      // RPC 대신 직접 UPDATE 쿼리 사용 (400 에러 방지)
      const { error: updateError } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false)

      if (updateError) throw updateError

      // 로컬 상태 업데이트
      setNotifications(prev =>
        prev.map(n => ({ ...n, is_read: true }))
      )
      setUnreadCount(0)
    } catch (err) {
      logger.error('Failed to mark all notifications as read:', err)
    }
  }, [supabase, user])

  // 초기 로드 및 실시간 구독
  useEffect(() => {
    if (!user) return

    fetchNotifications()

    // 실시간 구독
    const channel = supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
        },
        async (payload) => {
          if (payload.new.user_id !== user.id) return

          // actor 정보 가져오기
          let newNotification = payload.new as Notification

          if (payload.new.actor_id) {
            const { data: actorData } = await supabase
              .from('profiles')
              .select('id, full_name, avatar_url')
              .eq('id', payload.new.actor_id)
              .single()

            if (actorData) {
              newNotification = {
                ...newNotification,
                actor: actorData
              }
            }
          }

          // 새 알림을 목록 맨 앞에 추가
          setNotifications(prev => [newNotification, ...prev])
          setUnreadCount(prev => prev + 1)
        }
      )
      .subscribe()

    // 정리
    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchNotifications, supabase, user])

  return {
    notifications,
    unreadCount,
    isLoading,
    error,
    markAsRead,
    markAllAsRead,
    refetch: fetchNotifications,
  }
}

'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { createClient } from '@/lib/supabase/client'
import { createNamespacedLogger } from '@/lib/logger'
import { toast } from 'sonner'

const logger = createNamespacedLogger('SocialLogin')

interface SocialLoginProps {
  mode?: 'login' | 'signup'
}

type Provider = 'google' | 'apple' | 'kakao'

export default function SocialLogin({ mode = 'signup' }: SocialLoginProps) {
  const [isLoading, setIsLoading] = useState<Provider | null>(null)
  const actionText = mode === 'login' ? '로그인하기' : '가입하기'

  const handleSocialLogin = async (provider: Provider) => {
    try {
      setIsLoading(provider)
      logger.log(`Starting ${provider} OAuth login`)

      // Kakao는 커스텀 OAuth 플로우 사용 (현재 비활성화)
      // if (provider === 'kakao') {
      //   window.location.href = '/api/auth/kakao'
      //   return
      // }

      // Google, Apple은 Supabase OAuth 사용
      const supabase = createClient()
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
          queryParams: {
            ...(provider === 'google' && {
              prompt: 'select_account',
              access_type: 'offline',
            }),
          },
        },
      })

      if (error) {
        logger.error(`${provider} OAuth error:`, error)
        toast.error(`${provider === 'google' ? 'Google' : 'Apple'} 로그인에 실패했습니다. 다시 시도해주세요.`)
        setIsLoading(null)
      }
      // 성공 시 자동으로 리다이렉트되므로 로딩 상태는 유지
    } catch (error) {
      logger.error(`${provider} OAuth unexpected error:`, error)
      toast.error('로그인 중 오류가 발생했습니다.')
      setIsLoading(null)
    }
  }

  return (
    <div className="space-y-3">
      {/* Google */}
      <Button
        type="button"
        variant="outline"
        className="w-full"
        onClick={() => handleSocialLogin('google')}
        disabled={isLoading !== null}
      >
        <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
          <path
            fill="currentColor"
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
          />
          <path
            fill="currentColor"
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
          />
          <path
            fill="currentColor"
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
          />
          <path
            fill="currentColor"
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
          />
        </svg>
        {isLoading === 'google' ? 'Google로 로그인 중...' : `Google로 ${actionText}`}
      </Button>

      {/* Apple */}
      <Button
        type="button"
        variant="outline"
        className="w-full"
        disabled
      >
        <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
        </svg>
        Apple로 {actionText} (준비중)
      </Button>

      {/* Kakao */}
      <Button
        type="button"
        variant="outline"
        className="w-full"
        disabled
      >
        <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 3C6.477 3 2 6.477 2 10.8c0 2.827 1.88 5.292 4.688 6.66-.196.72-.643 2.401-.736 2.787-.114.467.171.46.36.334.147-.099 2.36-1.584 3.286-2.208.452.062.916.095 1.402.095 5.523 0 10-3.477 10-7.8S17.523 3 12 3z"/>
        </svg>
        카카오로 {actionText} (준비중)
      </Button>
    </div>
  )
}
